package com.capagemini.servletdemoclass.dao;

import java.util.List;

import com.capagemini.servletdemoclass.dto.EmployeeInfoBean;

public interface EmployeeDAO {
	public EmployeeInfoBean getEmployee(int empId);
	public boolean addEmployee(EmployeeInfoBean employeeIngoBean);
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean);
	public boolean deleteEmployee(int empId);
	public List<EmployeeInfoBean> getAllEmployees();
	public EmployeeInfoBean authenticate(int empId, String password);
	

}
