package com.capagemini.servletdemoclass.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/showEmployee")
public class ShowEmployeeServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//get the query string 
		String empIdVal = req.getParameter("empId");
		resp.setContentType("test/html");
		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("EmployeeId" +empIdVal);
		out.println("<br>EmployyeName= ShilpaMaalempati");
		out.println("<br>Employee salary : 30,000");
		out.println("</body>");
		out.println("</html>");
		
	}

}
