package com.capagemini.servletdemoclass.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/currentDate")
public class DateServlet extends HttpServlet {
//     public void DateServlet() {
//    	 System.out.println("instantiation phase");
//     }
//     @Override
//    public void init() throws ServletException {
//    	// TODO Auto-generated method stub
//    	super.init();
//    	System.out.println("intialization phase");
//    }
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ServletConfig servletConfig = getServletConfig();
		String configPram = servletConfig.getInitParameter("author");
		
		ServletContext servletContext = getServletContext();
		String contextPram = servletContext.getInitParameter("projectName");
		
		
		Date currentDate =  new Date();
		resp.setHeader("Refresh", 1);
		PrintWriter out = resp.getWriter();
		out.print("<html>");
		out.print("<body>");
		out.print("<h1>Current date and time is :"+   currentDate  + <"</h1>");
		out.print("<br>ConfigParam :"+   configPram);
		out.print("<br>ContextPram :"+   contextPram );
        out.print("</body>");
		out.print("</html>");
	}
//	@Override
//	public void destroy() {
//		// TODO Auto-generated method stub
//		super.destroy();
//		System.out.println("it is destruction phase");
//	}

}
